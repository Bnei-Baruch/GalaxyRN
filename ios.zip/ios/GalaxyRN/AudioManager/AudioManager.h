#import <React/RCTBridgeModule.h>

@interface AudioManager : NSObject <RCTBridgeModule>
@end 