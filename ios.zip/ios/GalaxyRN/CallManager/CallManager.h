#import <React/RCTBridgeModule.h>

@interface CallManager : NSObject <RCTBridgeModule>
@end 