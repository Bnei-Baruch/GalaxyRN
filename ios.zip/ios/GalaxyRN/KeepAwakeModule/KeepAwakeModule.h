#import <React/RCTBridgeModule.h>

@interface KeepAwakeModule : NSObject <RCTBridgeModule>
@end 