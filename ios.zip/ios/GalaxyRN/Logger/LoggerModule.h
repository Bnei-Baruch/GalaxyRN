#import <React/RCTBridgeModule.h>

@interface LoggerModule : NSObject <RCTBridgeModule>
@end 